const socket = io();
let peer;

const localVideo = document.getElementById('localVideo');
const remoteVideo = document.getElementById('remoteVideo');
const startCall = document.getElementById('startCall');
const generateProfile = document.getElementById('generateProfile');
const profileInfo = document.getElementById('profileInfo');

// Anoniem profiel genereren
generateProfile.onclick = () => {
  const profileId = 'user-' + Math.random().toString(36).substr(2, 9);
  localStorage.setItem('chat4menProfile', profileId);
  profileInfo.innerText = 'Je anoniem profiel ID: ' + profileId;
};

// Vraag toestemming voor camera en microfoon
navigator.mediaDevices.getUserMedia({ video: true, audio: true })
  .then(stream => {
    localVideo.srcObject = stream;

    startCall.onclick = () => {
      peer = new SimplePeer({
        initiator: true,
        trickle: false,
        stream: stream
      });

      peer.on('signal', data => {
        socket.emit('signal', data);
      });

      peer.on('stream', partnerStream => {
        remoteVideo.srcObject = partnerStream;
      });
    };

    socket.on('signal', data => {
      if (!peer) {
        peer = new SimplePeer({
          initiator: false,
          trickle: false,
          stream: stream
        });

        peer.on('signal', signalData => {
          socket.emit('signal', signalData);
        });

        peer.on('stream', partnerStream => {
          remoteVideo.srcObject = partnerStream;
        });
      }
      peer.signal(data);
    });

  })
  .catch(err => {
    console.error('Fout bij toegang tot media:', err);
    alert('Kon camera/microfoon niet openen.');
  });
